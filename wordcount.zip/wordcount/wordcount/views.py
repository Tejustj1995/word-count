import operator

from django.http import HttpResponse
from django.shortcuts import render


def homepage(request):
    return render(request, 'home.html')


def about(request):
    return render(request, 'about.html')



def count(request):
    text1 = request.GET['text1']
    lis = text1.split()
    word ={}
    for l in lis:
        if l in word:
            word[l] += 1
        else:
            word[l] = 1
    sword = sorted(word.items(), key=operator.itemgetter(1), reverse=True)
    return render(request, 'count.html', {'text1': text1, 'lis': len(lis), 'sword': sword})
